
mask-example-yolo - v1 mask_ver1
==============================

This dataset was exported via roboflow.ai on April 26, 2022 at 7:53 AM GMT

It includes 2034 images.
Mask are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random rotation of between -3 and +3 degrees
* Random brigthness adjustment of between -25 and +25 percent


